"""
╔══════════════════════════════════════════════════════════════════════════════╗
║              PERSONAL FINANCE TRACKER — DBMS PROJECT                        ║
║              Python + SQLite | Tkinter UI                                   ║
║              Single File: Python Code + SQL Schema + Project Docs           ║
╚══════════════════════════════════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  README / PROJECT DOCUMENTATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  PROJECT OVERVIEW
  ─────────────────
  A desktop application to manage personal finances — income, expenses,
  EMI/loans, and savings — built with Python (Tkinter UI) and SQLite.

  TECH STACK
  ──────────
  Language   : Python 3.x
  UI Library : Tkinter + ttk  (built-in, no install needed)
  Database   : SQLite via sqlite3  (built-in)
  Security   : SHA-256 password hashing via hashlib

  HOW TO RUN
  ──────────
  Requirements : Python 3.8 or higher  (no pip installs needed!)

  Steps:
    1. Save this file as  finance_tracker.py
    2. Open terminal / command prompt in the same folder
    3. Run:   python finance_tracker.py
    4. Register a new account → Login → Start tracking!
    5. A file  finance_tracker.db  is auto-created — that is your SQLite DB.

  FEATURES IMPLEMENTED
  ─────────────────────
  ✅ User Registration & Login  (SHA-256 hashed passwords)
  ✅ Dashboard — Income, Expenses, EMI, Salary, Savings KPI cards
  ✅ Remaining Balance banner  (Income − Expenses − EMI)
  ✅ Income Management          — Add / Edit / Delete
  ✅ Expense Tracker            — 6 categories, Add / Edit / Delete
  ✅ EMI / Loan Tracker         — Add / Edit / Delete
  ✅ Monthly Report             — This month's summary
  ✅ Expense breakdown by category  (visual bar chart)
  ✅ Savings Formula display

  SAVINGS FORMULA
  ───────────────
  Savings = Total Income − ( Total Expenses + Total EMI )

  CRUD OPERATIONS
  ───────────────
  CREATE  →  INSERT INTO  (add income / expense / EMI)
  READ    →  SELECT       (dashboard, tables, reports)
  UPDATE  →  UPDATE SET   (edit dialogs)
  DELETE  →  DELETE FROM  (delete buttons)

  PROJECT FILES (Single-file version)
  ─────────────────────────────────────
  finance_tracker.py   ← This file  (Python + SQL schema + Docs combined)
  finance_tracker.db   ← Auto-created SQLite database on first run

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SQL SCHEMA  (schema.sql — embedded below for reference)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  PRAGMA foreign_keys = ON;

  -- TABLE 1: users
  -- Primary Key: user_id  |  Each user has unique username + email
  CREATE TABLE IF NOT EXISTS users (
      user_id    INTEGER  PRIMARY KEY AUTOINCREMENT,
      username   TEXT     NOT NULL UNIQUE,
      password   TEXT     NOT NULL,           -- SHA-256 hashed
      full_name  TEXT     NOT NULL,
      email      TEXT     NOT NULL UNIQUE,
      created_at TEXT
  );

  -- TABLE 2: income
  -- Foreign Key: user_id → users(user_id)  ON DELETE CASCADE
  CREATE TABLE IF NOT EXISTS income (
      income_id   INTEGER  PRIMARY KEY AUTOINCREMENT,
      user_id     INTEGER  NOT NULL,
      source      TEXT     NOT NULL,
      amount      REAL     NOT NULL  CHECK(amount > 0),
      income_type TEXT     NOT NULL  DEFAULT 'salary',
      date        TEXT     NOT NULL,                      -- YYYY-MM-DD
      description TEXT,
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
  );

  -- TABLE 3: expenses
  -- Foreign Key: user_id → users(user_id)  ON DELETE CASCADE
  CREATE TABLE IF NOT EXISTS expenses (
      expense_id  INTEGER  PRIMARY KEY AUTOINCREMENT,
      user_id     INTEGER  NOT NULL,
      category    TEXT     NOT NULL,   -- Food/Rent/Travel/Shopping/Entertainment/Other
      amount      REAL     NOT NULL  CHECK(amount > 0),
      date        TEXT     NOT NULL,                      -- YYYY-MM-DD
      description TEXT,
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
  );

  -- TABLE 4: emi_loans
  -- Foreign Key: user_id → users(user_id)  ON DELETE CASCADE
  CREATE TABLE IF NOT EXISTS emi_loans (
      loan_id           INTEGER  PRIMARY KEY AUTOINCREMENT,
      user_id           INTEGER  NOT NULL,
      loan_name         TEXT     NOT NULL,
      total_amount      REAL     NOT NULL  CHECK(total_amount > 0),
      emi_amount        REAL     NOT NULL  CHECK(emi_amount > 0),
      interest_rate     REAL     NOT NULL  DEFAULT 0,     -- Annual %
      remaining_months  INTEGER  NOT NULL  CHECK(remaining_months >= 0),
      start_date        TEXT     NOT NULL,                -- YYYY-MM-DD
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
  );

  DATABASE RELATIONSHIPS
  ───────────────────────
  users (user_id) ──┬──► income    (user_id)   One-to-Many
                    ├──► expenses  (user_id)   One-to-Many
                    └──► emi_loans (user_id)   One-to-Many

  ON DELETE CASCADE: Agar user delete hoga toh uska saara data bhi delete hoga.

  USEFUL SQL QUERIES
  ──────────────────
  -- Total income for a user:
  SELECT SUM(amount) AS total_income FROM income WHERE user_id = 1;

  -- Expenses grouped by category:
  SELECT category, SUM(amount) AS total
  FROM expenses WHERE user_id = 1
  GROUP BY category ORDER BY total DESC;

  -- Net savings calculation:
  SELECT
      (SELECT COALESCE(SUM(amount),0) FROM income   WHERE user_id=1) -
      (SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=1) -
      (SELECT COALESCE(SUM(emi_amount),0) FROM emi_loans WHERE user_id=1)
  AS net_savings;

  -- Monthly expense report:
  SELECT strftime('%Y-%m', date) AS month, SUM(amount) AS monthly_expense
  FROM expenses WHERE user_id = 1
  GROUP BY month ORDER BY month DESC;

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PYTHON CODE STARTS BELOW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import hashlib
from datetime import datetime, date
import os

# ─────────────────────────────────────────────
#  DATABASE SETUP
# ─────────────────────────────────────────────

DB_NAME = "finance_tracker.db"

def get_conn():
    conn = sqlite3.connect(DB_NAME)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_conn()
    c = conn.cursor()

    # ── TABLE 1: users ──────────────────────────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id    INTEGER PRIMARY KEY AUTOINCREMENT,
            username   TEXT    NOT NULL UNIQUE,
            password   TEXT    NOT NULL,
            full_name  TEXT    NOT NULL,
            email      TEXT    NOT NULL UNIQUE,
            created_at TEXT    DEFAULT (DATE('now'))
        )
    """)

    # ── TABLE 2: income ─────────────────────────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS income (
            income_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            source      TEXT    NOT NULL,
            amount      REAL    NOT NULL CHECK(amount > 0),
            income_type TEXT    NOT NULL DEFAULT 'salary',
            date        TEXT    NOT NULL,
            description TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )
    """)

    # ── TABLE 3: expenses ───────────────────────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            expense_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            category    TEXT    NOT NULL,
            amount      REAL    NOT NULL CHECK(amount > 0),
            date        TEXT    NOT NULL,
            description TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )
    """)

    # ── TABLE 4: emi_loans ──────────────────────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS emi_loans (
            loan_id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id           INTEGER NOT NULL,
            loan_name         TEXT    NOT NULL,
            total_amount      REAL    NOT NULL CHECK(total_amount > 0),
            emi_amount        REAL    NOT NULL CHECK(emi_amount > 0),
            interest_rate     REAL    NOT NULL DEFAULT 0,
            remaining_months  INTEGER NOT NULL CHECK(remaining_months >= 0),
            start_date        TEXT    NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )
    """)

    conn.commit()
    conn.close()

def hash_password(pwd):
    return hashlib.sha256(pwd.encode()).hexdigest()


# ─────────────────────────────────────────────
#  COLOR PALETTE & FONTS
# ─────────────────────────────────────────────

COLORS = {
    "bg":         "#0F1117",
    "surface":    "#1A1D27",
    "card":       "#22263A",
    "border":     "#2E3352",
    "accent":     "#6C63FF",
    "accent2":    "#00D4AA",
    "accent3":    "#FF6B6B",
    "accent4":    "#FFB347",
    "text":       "#E8EAF6",
    "text_dim":   "#8B90A8",
    "success":    "#00D4AA",
    "danger":     "#FF6B6B",
    "warning":    "#FFB347",
    "white":      "#FFFFFF",
    "input_bg":   "#12151F",
}

FONT_TITLE  = ("Segoe UI", 22, "bold")
FONT_H2     = ("Segoe UI", 14, "bold")
FONT_H3     = ("Segoe UI", 11, "bold")
FONT_BODY   = ("Segoe UI", 10)
FONT_SMALL  = ("Segoe UI", 9)
FONT_LABEL  = ("Segoe UI", 10)
FONT_MONO   = ("Consolas", 10)

EXPENSE_CATEGORIES = ["Food", "Rent", "Travel", "Shopping", "Entertainment", "Other"]
INCOME_TYPES       = ["Salary", "Freelance", "Business", "Investment", "Gift", "Other"]


# ─────────────────────────────────────────────
#  HELPER WIDGETS
# ─────────────────────────────────────────────

def styled_frame(parent, bg=None, **kw):
    return tk.Frame(parent, bg=bg or COLORS["surface"], **kw)

def label(parent, text, font=FONT_BODY, fg=None, bg=None, **kw):
    return tk.Label(parent, text=text, font=font,
                    fg=fg or COLORS["text"], bg=bg or COLORS["surface"], **kw)

def entry(parent, show=None, width=28):
    e = tk.Entry(parent, show=show, width=width,
                 font=FONT_BODY,
                 bg=COLORS["input_bg"], fg=COLORS["text"],
                 insertbackground=COLORS["accent"],
                 relief="flat",
                 highlightthickness=1,
                 highlightcolor=COLORS["accent"],
                 highlightbackground=COLORS["border"])
    return e

def btn(parent, text, command, color=None, fg=None, width=None, **kw):
    b = tk.Button(parent, text=text, command=command,
                  font=FONT_H3,
                  bg=color or COLORS["accent"],
                  fg=fg or COLORS["white"],
                  activebackground=COLORS["accent"],
                  activeforeground=COLORS["white"],
                  relief="flat", cursor="hand2",
                  padx=16, pady=8, **kw)
    if width:
        b.configure(width=width)
    return b

def card(parent, **kw):
    return tk.Frame(parent, bg=COLORS["card"],
                    highlightthickness=1,
                    highlightbackground=COLORS["border"], **kw)

def separator(parent, bg=None):
    return tk.Frame(parent, bg=bg or COLORS["border"], height=1)


# ─────────────────────────────────────────────
#  AUTH WINDOW  (Login + Register)
# ─────────────────────────────────────────────

class AuthWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Finance Tracker — Login")
        self.root.geometry("520x620")
        self.root.configure(bg=COLORS["bg"])
        self.root.resizable(False, False)
        self._center()
        self._build_login()

    def _center(self):
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth()  - 520) // 2
        y = (self.root.winfo_screenheight() - 620) // 2
        self.root.geometry(f"520x620+{x}+{y}")

    def _clear(self):
        for w in self.root.winfo_children():
            w.destroy()

    # ── LOGIN UI ────────────────────────────────────────────────────────
    def _build_login(self):
        self._clear()
        wrap = styled_frame(self.root, bg=COLORS["bg"])
        wrap.pack(expand=True, fill="both", padx=50)

        # Logo area
        logo_f = styled_frame(wrap, bg=COLORS["bg"])
        logo_f.pack(pady=(60, 0))
        tk.Label(logo_f, text="₹", font=("Segoe UI", 48, "bold"),
                 fg=COLORS["accent"], bg=COLORS["bg"]).pack()
        tk.Label(wrap, text="Finance Tracker", font=FONT_TITLE,
                 fg=COLORS["text"], bg=COLORS["bg"]).pack()
        tk.Label(wrap, text="Your Personal Money Manager", font=FONT_SMALL,
                 fg=COLORS["text_dim"], bg=COLORS["bg"]).pack(pady=(4, 30))

        # Card
        c = card(wrap)
        c.pack(fill="x", pady=4)
        inner = styled_frame(c, bg=COLORS["card"])
        inner.pack(padx=28, pady=28, fill="x")

        label(inner, "Username", bg=COLORS["card"], fg=COLORS["text_dim"]).pack(anchor="w")
        self.l_user = entry(inner)
        self.l_user.pack(fill="x", pady=(4, 14), ipady=8)

        label(inner, "Password", bg=COLORS["card"], fg=COLORS["text_dim"]).pack(anchor="w")
        self.l_pass = entry(inner, show="•")
        self.l_pass.pack(fill="x", pady=(4, 20), ipady=8)

        btn(inner, "Login", self._login, width=30).pack(fill="x")

        separator(wrap, bg=COLORS["bg"]).pack(fill="x", pady=20)

        tk.Label(wrap, text="Don't have an account?",
                 font=FONT_SMALL, fg=COLORS["text_dim"], bg=COLORS["bg"]).pack()
        tk.Button(wrap, text="Create Account →",
                  font=("Segoe UI", 10, "bold"),
                  fg=COLORS["accent"], bg=COLORS["bg"],
                  bd=0, cursor="hand2",
                  command=self._build_register).pack(pady=4)

        self.l_user.focus()
        self.root.bind("<Return>", lambda e: self._login())

    def _login(self):
        u, p = self.l_user.get().strip(), self.l_pass.get().strip()
        if not u or not p:
            messagebox.showerror("Error", "Please fill all fields")
            return
        conn = get_conn()
        row = conn.execute(
            "SELECT user_id, full_name FROM users WHERE username=? AND password=?",
            (u, hash_password(p))
        ).fetchone()
        conn.close()
        if row:
            self.root.destroy()
            _launch_dashboard(row[0], row[1])
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")

    # ── REGISTER UI ─────────────────────────────────────────────────────
    def _build_register(self):
        self._clear()
        self.root.geometry("520x700")
        self._center()
        wrap = styled_frame(self.root, bg=COLORS["bg"])
        wrap.pack(expand=True, fill="both", padx=50)

        tk.Label(wrap, text="Create Account", font=FONT_TITLE,
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(pady=(40, 4))
        tk.Label(wrap, text="Join Finance Tracker today", font=FONT_SMALL,
                 fg=COLORS["text_dim"], bg=COLORS["bg"]).pack(pady=(0, 20))

        c = card(wrap)
        c.pack(fill="x")
        inner = styled_frame(c, bg=COLORS["card"])
        inner.pack(padx=28, pady=28, fill="x")

        fields = [
            ("Full Name",  False),
            ("Username",   False),
            ("Email",      False),
            ("Password",   True),
            ("Confirm Password", True),
        ]
        self.reg_entries = {}
        for lbl, secret in fields:
            label(inner, lbl, bg=COLORS["card"], fg=COLORS["text_dim"]).pack(anchor="w")
            e = entry(inner, show="•" if secret else None)
            e.pack(fill="x", pady=(4, 12), ipady=8)
            self.reg_entries[lbl] = e

        btn(inner, "Register", self._register, color=COLORS["accent2"],
            fg=COLORS["bg"]).pack(fill="x", pady=(8, 0))

        tk.Button(wrap, text="← Back to Login",
                  font=("Segoe UI", 10, "bold"),
                  fg=COLORS["accent"], bg=COLORS["bg"],
                  bd=0, cursor="hand2",
                  command=self._build_login).pack(pady=16)

    def _register(self):
        e = self.reg_entries
        name  = e["Full Name"].get().strip()
        user  = e["Username"].get().strip()
        email = e["Email"].get().strip()
        pwd   = e["Password"].get().strip()
        cpwd  = e["Confirm Password"].get().strip()

        if not all([name, user, email, pwd, cpwd]):
            messagebox.showerror("Error", "Please fill all fields")
            return
        if pwd != cpwd:
            messagebox.showerror("Error", "Passwords do not match")
            return
        if len(pwd) < 6:
            messagebox.showerror("Error", "Password must be at least 6 characters")
            return

        try:
            conn = get_conn()
            conn.execute(
                "INSERT INTO users (username, password, full_name, email) VALUES (?,?,?,?)",
                (user, hash_password(pwd), name, email)
            )
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", f"Account created! Welcome, {name} 🎉")
            self._build_login()
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Username or Email already exists")


# ─────────────────────────────────────────────
#  MAIN DASHBOARD APP
# ─────────────────────────────────────────────

class FinanceApp:
    def __init__(self, root, user_id, full_name):
        self.root       = root
        self.user_id    = user_id
        self.full_name  = full_name
        self.active_tab = None

        self.root.title(f"Finance Tracker — {full_name}")
        self.root.geometry("1100x700")
        self.root.configure(bg=COLORS["bg"])
        self.root.resizable(True, True)
        self._center()
        self._build_ui()
        self._show_tab("dashboard")

    def _center(self):
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth()  - 1100) // 2
        y = (self.root.winfo_screenheight() - 700)  // 2
        self.root.geometry(f"1100x700+{x}+{y}")

    # ── LAYOUT ──────────────────────────────────────────────────────────
    def _build_ui(self):
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure(0, weight=1)

        # Sidebar
        self.sidebar = styled_frame(self.root, bg=COLORS["surface"], width=220)
        self.sidebar.grid(row=0, column=0, sticky="ns")
        self.sidebar.pack_propagate(False)
        self._build_sidebar()

        # Main
        self.main_area = styled_frame(self.root, bg=COLORS["bg"])
        self.main_area.grid(row=0, column=1, sticky="nsew")
        self.content_frame = styled_frame(self.main_area, bg=COLORS["bg"])
        self.content_frame.pack(expand=True, fill="both")

    def _build_sidebar(self):
        # Logo
        logo = styled_frame(self.sidebar, bg=COLORS["surface"])
        logo.pack(fill="x", pady=(20, 10))
        tk.Label(logo, text="₹ FinTrack", font=("Segoe UI", 16, "bold"),
                 fg=COLORS["accent"], bg=COLORS["surface"]).pack()
        tk.Label(logo, text=self.full_name, font=FONT_SMALL,
                 fg=COLORS["text_dim"], bg=COLORS["surface"]).pack(pady=(2, 0))
        separator(self.sidebar).pack(fill="x", padx=16, pady=14)

        nav_items = [
            ("🏠", "Dashboard",   "dashboard"),
            ("💰", "Income",      "income"),
            ("💸", "Expenses",    "expenses"),
            ("🏦", "EMI / Loans", "emi"),
            ("📊", "Reports",     "reports"),
        ]
        self.nav_btns = {}
        for icon, label_text, key in nav_items:
            f = tk.Frame(self.sidebar, bg=COLORS["surface"], cursor="hand2")
            f.pack(fill="x", padx=12, pady=2)
            lbl = tk.Label(f, text=f"  {icon}  {label_text}",
                           font=FONT_H3, bg=COLORS["surface"],
                           fg=COLORS["text_dim"], anchor="w", pady=10)
            lbl.pack(fill="x", padx=4)
            f.bind("<Button-1>",  lambda e, k=key: self._show_tab(k))
            lbl.bind("<Button-1>", lambda e, k=key: self._show_tab(k))
            self.nav_btns[key] = (f, lbl)

        # Logout
        separator(self.sidebar).pack(fill="x", padx=16, pady=14, side="bottom")
        tk.Button(self.sidebar, text="⏻  Logout",
                  font=FONT_H3, bg=COLORS["surface"],
                  fg=COLORS["danger"], bd=0, cursor="hand2",
                  command=self._logout).pack(side="bottom", fill="x", padx=24, pady=14)

    def _show_tab(self, key):
        # Highlight nav
        for k, (f, l) in self.nav_btns.items():
            if k == key:
                f.configure(bg=COLORS["card"])
                l.configure(bg=COLORS["card"], fg=COLORS["accent"])
            else:
                f.configure(bg=COLORS["surface"])
                l.configure(bg=COLORS["surface"], fg=COLORS["text_dim"])

        for w in self.content_frame.winfo_children():
            w.destroy()

        tabs = {
            "dashboard": self._tab_dashboard,
            "income":    self._tab_income,
            "expenses":  self._tab_expenses,
            "emi":       self._tab_emi,
            "reports":   self._tab_reports,
        }
        tabs.get(key, self._tab_dashboard)()
        self.active_tab = key

    def _logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.root.destroy()
            _launch_auth()

    # ── FETCH SUMMARIES ──────────────────────────────────────────────────
    def _get_summary(self):
        conn = get_conn()
        uid  = self.user_id

        total_income = conn.execute(
            "SELECT COALESCE(SUM(amount),0) FROM income WHERE user_id=?", (uid,)
        ).fetchone()[0]

        total_salary = conn.execute(
            "SELECT COALESCE(SUM(amount),0) FROM income WHERE user_id=? AND LOWER(income_type)='salary'", (uid,)
        ).fetchone()[0]

        total_expenses = conn.execute(
            "SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=?", (uid,)
        ).fetchone()[0]

        total_emi = conn.execute(
            "SELECT COALESCE(SUM(emi_amount),0) FROM emi_loans WHERE user_id=?", (uid,)
        ).fetchone()[0]

        conn.close()

        savings  = total_income - (total_expenses + total_emi)
        balance  = savings
        return {
            "income":   total_income,
            "salary":   total_salary,
            "expenses": total_expenses,
            "emi":      total_emi,
            "savings":  savings,
            "balance":  balance,
        }

    # ════════════════════════════════════════════
    #  TAB: DASHBOARD
    # ════════════════════════════════════════════
    def _tab_dashboard(self):
        cf = self.content_frame
        s  = self._get_summary()

        # Header
        hdr = styled_frame(cf, bg=COLORS["bg"])
        hdr.pack(fill="x", padx=28, pady=(28, 8))
        tk.Label(hdr, text=f"Welcome back, {self.full_name.split()[0]}! 👋",
                 font=FONT_TITLE, fg=COLORS["text"], bg=COLORS["bg"]).pack(anchor="w")
        tk.Label(hdr, text=f"Here's your financial overview — {date.today().strftime('%B %d, %Y')}",
                 font=FONT_SMALL, fg=COLORS["text_dim"], bg=COLORS["bg"]).pack(anchor="w")

        separator(cf, bg=COLORS["border"]).pack(fill="x", padx=28, pady=8)

        # KPI CARDS
        kpi_frame = styled_frame(cf, bg=COLORS["bg"])
        kpi_frame.pack(fill="x", padx=28)
        kpi_frame.columnconfigure((0,1,2,3,4), weight=1)

        cards = [
            ("💰 Total Income",  f"₹{s['income']:,.2f}",   COLORS["accent"]),
            ("💸 Total Expenses", f"₹{s['expenses']:,.2f}", COLORS["danger"]),
            ("🏦 Total EMI",     f"₹{s['emi']:,.2f}",      COLORS["warning"]),
            ("🏠 Total Salary",  f"₹{s['salary']:,.2f}",   COLORS["accent2"]),
            ("💎 Net Savings",   f"₹{s['savings']:,.2f}",  COLORS["success"] if s["savings"] >= 0 else COLORS["danger"]),
        ]
        for i, (title, val, color) in enumerate(cards):
            c = tk.Frame(kpi_frame, bg=COLORS["card"],
                         highlightthickness=1,
                         highlightbackground=COLORS["border"])
            c.grid(row=0, column=i, padx=6, pady=4, sticky="ew")
            tk.Label(c, text=title, font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["card"]).pack(anchor="w", padx=14, pady=(14,2))
            tk.Label(c, text=val, font=("Segoe UI", 15, "bold"),
                     fg=color, bg=COLORS["card"]).pack(anchor="w", padx=14, pady=(0,14))

        # Remaining Balance Banner
        bal_color = COLORS["success"] if s["balance"] >= 0 else COLORS["danger"]
        bal_card = tk.Frame(cf, bg=bal_color)
        bal_card.pack(fill="x", padx=28, pady=10)
        tk.Label(bal_card,
                 text=f"  Remaining Balance:  ₹{s['balance']:,.2f}   (Income – Expenses – EMI)",
                 font=("Segoe UI", 12, "bold"), fg=COLORS["bg"], bg=bal_color,
                 pady=12).pack(anchor="w", padx=14)

        # Two columns
        cols = styled_frame(cf, bg=COLORS["bg"])
        cols.pack(fill="both", expand=True, padx=28, pady=(4,20))
        cols.columnconfigure(0, weight=1)
        cols.columnconfigure(1, weight=1)

        # Recent Expenses
        left = tk.Frame(cols, bg=COLORS["card"],
                        highlightthickness=1, highlightbackground=COLORS["border"])
        left.grid(row=0, column=0, padx=(0,8), sticky="nsew")
        tk.Label(left, text="Recent Expenses", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).pack(anchor="w", padx=16, pady=(14,6))
        separator(left, bg=COLORS["border"]).pack(fill="x", padx=8)

        conn = get_conn()
        rec_exp = conn.execute(
            """SELECT category, amount, date FROM expenses
               WHERE user_id=? ORDER BY date DESC LIMIT 6""",
            (self.user_id,)
        ).fetchall()
        if rec_exp:
            for cat, amt, dt in rec_exp:
                rf = tk.Frame(left, bg=COLORS["card"])
                rf.pack(fill="x", padx=16, pady=4)
                tk.Label(rf, text=cat, font=FONT_BODY,
                         fg=COLORS["text"], bg=COLORS["card"]).pack(side="left")
                tk.Label(rf, text=f"-₹{amt:,.0f}", font=FONT_H3,
                         fg=COLORS["danger"], bg=COLORS["card"]).pack(side="right")
                tk.Label(rf, text=dt, font=FONT_SMALL,
                         fg=COLORS["text_dim"], bg=COLORS["card"]).pack(side="right", padx=8)
        else:
            tk.Label(left, text="No expenses yet", font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["card"]).pack(pady=20)

        # Active EMIs
        right = tk.Frame(cols, bg=COLORS["card"],
                         highlightthickness=1, highlightbackground=COLORS["border"])
        right.grid(row=0, column=1, padx=(8,0), sticky="nsew")
        tk.Label(right, text="Active EMI / Loans", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).pack(anchor="w", padx=16, pady=(14,6))
        separator(right, bg=COLORS["border"]).pack(fill="x", padx=8)

        emis = conn.execute(
            """SELECT loan_name, emi_amount, remaining_months FROM emi_loans
               WHERE user_id=? ORDER BY loan_id DESC LIMIT 6""",
            (self.user_id,)
        ).fetchall()
        conn.close()

        if emis:
            for name, amt, months in emis:
                rf = tk.Frame(right, bg=COLORS["card"])
                rf.pack(fill="x", padx=16, pady=4)
                tk.Label(rf, text=name, font=FONT_BODY,
                         fg=COLORS["text"], bg=COLORS["card"]).pack(side="left")
                tk.Label(rf, text=f"₹{amt:,.0f}/mo", font=FONT_H3,
                         fg=COLORS["warning"], bg=COLORS["card"]).pack(side="right")
                tk.Label(rf, text=f"{months}m left", font=FONT_SMALL,
                         fg=COLORS["text_dim"], bg=COLORS["card"]).pack(side="right", padx=8)
        else:
            tk.Label(right, text="No EMIs added yet", font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["card"]).pack(pady=20)

    # ════════════════════════════════════════════
    #  TAB: INCOME
    # ════════════════════════════════════════════
    def _tab_income(self):
        cf = self.content_frame
        self._page_header(cf, "💰 Income Management", "Track all your income sources")

        # Form Card
        form_c = card(cf)
        form_c.pack(fill="x", padx=28, pady=(0, 14))
        fi = styled_frame(form_c, bg=COLORS["card"])
        fi.pack(padx=20, pady=16, fill="x")

        tk.Label(fi, text="Add New Income", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0,12))

        # Row 1
        lf = [("Source / Description", 0), ("Amount (₹)", 1), ("Type", 2), ("Date", 3)]
        for txt, col in lf:
            tk.Label(fi, text=txt, font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["card"]).grid(row=1, column=col, sticky="w", padx=6)

        self.inc_src  = tk.Entry(fi, font=FONT_BODY, bg=COLORS["input_bg"],
                                 fg=COLORS["text"], insertbackground=COLORS["accent"],
                                 relief="flat", highlightthickness=1,
                                 highlightbackground=COLORS["border"])
        self.inc_src.grid(row=2, column=0, padx=6, pady=4, ipady=6, sticky="ew")

        self.inc_amt  = tk.Entry(fi, font=FONT_BODY, bg=COLORS["input_bg"],
                                 fg=COLORS["text"], insertbackground=COLORS["accent"],
                                 relief="flat", highlightthickness=1,
                                 highlightbackground=COLORS["border"], width=12)
        self.inc_amt.grid(row=2, column=1, padx=6, pady=4, ipady=6)

        self.inc_type = ttk.Combobox(fi, values=INCOME_TYPES, state="readonly", width=14, font=FONT_BODY)
        self.inc_type.set("Salary")
        self.inc_type.grid(row=2, column=2, padx=6, pady=4, ipady=6)

        self.inc_date = tk.Entry(fi, font=FONT_BODY, bg=COLORS["input_bg"],
                                 fg=COLORS["text"], insertbackground=COLORS["accent"],
                                 relief="flat", highlightthickness=1,
                                 highlightbackground=COLORS["border"], width=14)
        self.inc_date.insert(0, str(date.today()))
        self.inc_date.grid(row=2, column=3, padx=6, pady=4, ipady=6)

        fi.columnconfigure(0, weight=1)

        btn_f = styled_frame(fi, bg=COLORS["card"])
        btn_f.grid(row=3, column=0, columnspan=4, sticky="e", pady=(10,0))
        btn(btn_f, "+ Add Income", self._add_income, color=COLORS["accent2"], fg=COLORS["bg"]).pack(side="right", padx=4)

        # Table
        self._income_table(cf)

    def _income_table(self, cf):
        tc = card(cf)
        tc.pack(fill="both", expand=True, padx=28, pady=(0,20))
        hdr = styled_frame(tc, bg=COLORS["card"])
        hdr.pack(fill="x", padx=12, pady=(12,4))
        tk.Label(hdr, text="Income Records", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).pack(side="left")

        cols = ("ID", "Source", "Type", "Amount", "Date")
        self.inc_tree = self._make_tree(tc, cols, [40, 200, 100, 100, 100])
        self._load_income()

        bf = styled_frame(tc, bg=COLORS["card"])
        bf.pack(fill="x", padx=12, pady=8)
        btn(bf, "🗑 Delete", self._del_income, color=COLORS["danger"]).pack(side="right", padx=4)
        btn(bf, "✏ Edit",   self._edit_income, color=COLORS["warning"], fg=COLORS["bg"]).pack(side="right", padx=4)

    def _make_tree(self, parent, cols, widths):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Custom.Treeview",
                        background=COLORS["card"],
                        fieldbackground=COLORS["card"],
                        foreground=COLORS["text"],
                        rowheight=32,
                        font=FONT_BODY)
        style.configure("Custom.Treeview.Heading",
                        background=COLORS["surface"],
                        foreground=COLORS["text_dim"],
                        font=FONT_H3, relief="flat")
        style.map("Custom.Treeview", background=[("selected", COLORS["accent"])])

        frame = tk.Frame(parent, bg=COLORS["card"])
        frame.pack(fill="both", expand=True, padx=12, pady=4)

        tree = ttk.Treeview(frame, columns=cols, show="headings",
                            style="Custom.Treeview")
        sb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)

        for col, w in zip(cols, widths):
            tree.heading(col, text=col)
            tree.column(col, width=w, anchor="center")

        tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        return tree

    def _load_income(self):
        for row in self.inc_tree.get_children():
            self.inc_tree.delete(row)
        conn = get_conn()
        rows = conn.execute(
            "SELECT income_id, source, income_type, amount, date FROM income WHERE user_id=? ORDER BY date DESC",
            (self.user_id,)
        ).fetchall()
        conn.close()
        for r in rows:
            self.inc_tree.insert("", "end", values=(r[0], r[1], r[2], f"₹{r[3]:,.2f}", r[4]))

    def _add_income(self):
        src  = self.inc_src.get().strip()
        amt  = self.inc_amt.get().strip()
        typ  = self.inc_type.get()
        dt   = self.inc_date.get().strip()
        if not all([src, amt, dt]):
            messagebox.showerror("Error", "Please fill all fields")
            return
        try:
            amt = float(amt)
            conn = get_conn()
            conn.execute(
                "INSERT INTO income (user_id, source, amount, income_type, date) VALUES (?,?,?,?,?)",
                (self.user_id, src, amt, typ, dt)
            )
            conn.commit()
            conn.close()
            self.inc_src.delete(0, "end")
            self.inc_amt.delete(0, "end")
            self._load_income()
            messagebox.showinfo("Success", "Income added! ✅")
        except ValueError:
            messagebox.showerror("Error", "Invalid amount")

    def _del_income(self):
        sel = self.inc_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a row")
            return
        inc_id = self.inc_tree.item(sel[0])["values"][0]
        if messagebox.askyesno("Delete", "Delete this income entry?"):
            conn = get_conn()
            conn.execute("DELETE FROM income WHERE income_id=?", (inc_id,))
            conn.commit()
            conn.close()
            self._load_income()

    def _edit_income(self):
        sel = self.inc_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a row to edit")
            return
        vals = self.inc_tree.item(sel[0])["values"]
        inc_id = vals[0]
        EditIncomeDialog(self.root, inc_id, self._load_income)

    # ════════════════════════════════════════════
    #  TAB: EXPENSES
    # ════════════════════════════════════════════
    def _tab_expenses(self):
        cf = self.content_frame
        self._page_header(cf, "💸 Expense Tracker", "Monitor where your money goes")

        form_c = card(cf)
        form_c.pack(fill="x", padx=28, pady=(0,14))
        fi = styled_frame(form_c, bg=COLORS["card"])
        fi.pack(padx=20, pady=16, fill="x")

        tk.Label(fi, text="Add New Expense", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).grid(row=0, column=0, columnspan=5, sticky="w", pady=(0,12))

        heads = ["Category", "Amount (₹)", "Date", "Description"]
        for i, h in enumerate(heads):
            tk.Label(fi, text=h, font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["card"]).grid(row=1, column=i, sticky="w", padx=6)

        self.exp_cat = ttk.Combobox(fi, values=EXPENSE_CATEGORIES, state="readonly", width=14, font=FONT_BODY)
        self.exp_cat.set("Food")
        self.exp_cat.grid(row=2, column=0, padx=6, pady=4, ipady=6)

        self.exp_amt = tk.Entry(fi, font=FONT_BODY, bg=COLORS["input_bg"],
                                fg=COLORS["text"], insertbackground=COLORS["accent"],
                                relief="flat", highlightthickness=1,
                                highlightbackground=COLORS["border"], width=12)
        self.exp_amt.grid(row=2, column=1, padx=6, pady=4, ipady=6)

        self.exp_date = tk.Entry(fi, font=FONT_BODY, bg=COLORS["input_bg"],
                                 fg=COLORS["text"], insertbackground=COLORS["accent"],
                                 relief="flat", highlightthickness=1,
                                 highlightbackground=COLORS["border"], width=14)
        self.exp_date.insert(0, str(date.today()))
        self.exp_date.grid(row=2, column=2, padx=6, pady=4, ipady=6)

        self.exp_desc = tk.Entry(fi, font=FONT_BODY, bg=COLORS["input_bg"],
                                 fg=COLORS["text"], insertbackground=COLORS["accent"],
                                 relief="flat", highlightthickness=1,
                                 highlightbackground=COLORS["border"], width=22)
        self.exp_desc.grid(row=2, column=3, padx=6, pady=4, ipady=6)

        fi.columnconfigure(3, weight=1)

        bf = styled_frame(fi, bg=COLORS["card"])
        bf.grid(row=3, column=0, columnspan=5, sticky="e", pady=(10,0))
        btn(bf, "+ Add Expense", self._add_expense, color=COLORS["danger"]).pack(side="right")

        self._expense_table(cf)

    def _expense_table(self, cf):
        tc = card(cf)
        tc.pack(fill="both", expand=True, padx=28, pady=(0,20))
        tk.Label(tc, text="Expense Records", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).pack(anchor="w", padx=16, pady=(12,4))

        cols = ("ID", "Category", "Amount", "Date", "Description")
        self.exp_tree = self._make_tree(tc, cols, [40, 120, 100, 100, 250])
        self._load_expenses()

        bf = styled_frame(tc, bg=COLORS["card"])
        bf.pack(fill="x", padx=12, pady=8)
        btn(bf, "🗑 Delete", self._del_expense, color=COLORS["danger"]).pack(side="right", padx=4)
        btn(bf, "✏ Edit",   self._edit_expense, color=COLORS["warning"], fg=COLORS["bg"]).pack(side="right", padx=4)

    def _load_expenses(self):
        for row in self.exp_tree.get_children():
            self.exp_tree.delete(row)
        conn = get_conn()
        rows = conn.execute(
            "SELECT expense_id, category, amount, date, description FROM expenses WHERE user_id=? ORDER BY date DESC",
            (self.user_id,)
        ).fetchall()
        conn.close()
        for r in rows:
            self.exp_tree.insert("", "end", values=(r[0], r[1], f"₹{r[2]:,.2f}", r[3], r[4] or ""))

    def _add_expense(self):
        cat  = self.exp_cat.get()
        amt  = self.exp_amt.get().strip()
        dt   = self.exp_date.get().strip()
        desc = self.exp_desc.get().strip()
        if not all([cat, amt, dt]):
            messagebox.showerror("Error", "Please fill all required fields")
            return
        try:
            amt = float(amt)
            conn = get_conn()
            conn.execute(
                "INSERT INTO expenses (user_id, category, amount, date, description) VALUES (?,?,?,?,?)",
                (self.user_id, cat, amt, dt, desc)
            )
            conn.commit()
            conn.close()
            self.exp_amt.delete(0, "end")
            self.exp_desc.delete(0, "end")
            self._load_expenses()
            messagebox.showinfo("Success", "Expense added! ✅")
        except ValueError:
            messagebox.showerror("Error", "Invalid amount")

    def _del_expense(self):
        sel = self.exp_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a row")
            return
        exp_id = self.exp_tree.item(sel[0])["values"][0]
        if messagebox.askyesno("Delete", "Delete this expense?"):
            conn = get_conn()
            conn.execute("DELETE FROM expenses WHERE expense_id=?", (exp_id,))
            conn.commit()
            conn.close()
            self._load_expenses()

    def _edit_expense(self):
        sel = self.exp_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a row to edit")
            return
        exp_id = self.exp_tree.item(sel[0])["values"][0]
        EditExpenseDialog(self.root, exp_id, self._load_expenses)

    # ════════════════════════════════════════════
    #  TAB: EMI / LOANS
    # ════════════════════════════════════════════
    def _tab_emi(self):
        cf = self.content_frame
        self._page_header(cf, "🏦 EMI / Loan Tracker", "Manage your loans and EMIs")

        form_c = card(cf)
        form_c.pack(fill="x", padx=28, pady=(0,14))
        fi = styled_frame(form_c, bg=COLORS["card"])
        fi.pack(padx=20, pady=16, fill="x")

        tk.Label(fi, text="Add New Loan / EMI", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).grid(row=0, column=0, columnspan=6, sticky="w", pady=(0,12))

        heads = ["Loan Name", "Total Amount (₹)", "EMI (₹/month)", "Interest Rate (%)", "Remaining Months", "Start Date"]
        for i, h in enumerate(heads):
            tk.Label(fi, text=h, font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["card"]).grid(row=1, column=i, sticky="w", padx=5)

        self.emi_entries = {}
        defaults = ["", "", "", "0", "", str(date.today())]
        widths   = [16, 14, 12, 10, 12, 14]
        for i, (_, dflt, w) in enumerate(zip(heads, defaults, widths)):
            e = tk.Entry(fi, font=FONT_BODY, bg=COLORS["input_bg"],
                         fg=COLORS["text"], insertbackground=COLORS["accent"],
                         relief="flat", highlightthickness=1,
                         highlightbackground=COLORS["border"], width=w)
            if dflt:
                e.insert(0, dflt)
            e.grid(row=2, column=i, padx=5, pady=4, ipady=6)
            self.emi_entries[i] = e

        bf = styled_frame(fi, bg=COLORS["card"])
        bf.grid(row=3, column=0, columnspan=6, sticky="e", pady=(10,0))
        btn(bf, "+ Add EMI", self._add_emi, color=COLORS["warning"], fg=COLORS["bg"]).pack(side="right")

        # Table
        tc = card(cf)
        tc.pack(fill="both", expand=True, padx=28, pady=(0,20))
        tk.Label(tc, text="EMI Records", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).pack(anchor="w", padx=16, pady=(12,4))

        cols = ("ID", "Loan Name", "Total", "EMI/Month", "Interest%", "Months Left", "Start Date")
        self.emi_tree = self._make_tree(tc, cols, [40, 160, 100, 100, 80, 90, 100])
        self._load_emis()

        bf2 = styled_frame(tc, bg=COLORS["card"])
        bf2.pack(fill="x", padx=12, pady=8)
        btn(bf2, "🗑 Delete", self._del_emi, color=COLORS["danger"]).pack(side="right", padx=4)
        btn(bf2, "✏ Edit",   self._edit_emi, color=COLORS["warning"], fg=COLORS["bg"]).pack(side="right", padx=4)

    def _load_emis(self):
        for row in self.emi_tree.get_children():
            self.emi_tree.delete(row)
        conn = get_conn()
        rows = conn.execute(
            "SELECT loan_id, loan_name, total_amount, emi_amount, interest_rate, remaining_months, start_date FROM emi_loans WHERE user_id=? ORDER BY loan_id DESC",
            (self.user_id,)
        ).fetchall()
        conn.close()
        for r in rows:
            self.emi_tree.insert("", "end",
                values=(r[0], r[1], f"₹{r[2]:,.0f}", f"₹{r[3]:,.0f}", f"{r[4]}%", r[5], r[6]))

    def _add_emi(self):
        e = self.emi_entries
        try:
            name    = e[0].get().strip()
            total   = float(e[1].get())
            emi     = float(e[2].get())
            rate    = float(e[3].get())
            months  = int(e[4].get())
            start   = e[5].get().strip()
            if not name:
                raise ValueError()
            conn = get_conn()
            conn.execute(
                "INSERT INTO emi_loans (user_id, loan_name, total_amount, emi_amount, interest_rate, remaining_months, start_date) VALUES (?,?,?,?,?,?,?)",
                (self.user_id, name, total, emi, rate, months, start)
            )
            conn.commit()
            conn.close()
            for ent in e.values():
                ent.delete(0, "end")
            e[3].insert(0, "0")
            e[5].insert(0, str(date.today()))
            self._load_emis()
            messagebox.showinfo("Success", "EMI / Loan added! ✅")
        except (ValueError, TypeError):
            messagebox.showerror("Error", "Please fill all fields correctly")

    def _del_emi(self):
        sel = self.emi_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a row")
            return
        loan_id = self.emi_tree.item(sel[0])["values"][0]
        if messagebox.askyesno("Delete", "Delete this EMI entry?"):
            conn = get_conn()
            conn.execute("DELETE FROM emi_loans WHERE loan_id=?", (loan_id,))
            conn.commit()
            conn.close()
            self._load_emis()

    def _edit_emi(self):
        sel = self.emi_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a row to edit")
            return
        loan_id = self.emi_tree.item(sel[0])["values"][0]
        EditEmiDialog(self.root, loan_id, self._load_emis)

    # ════════════════════════════════════════════
    #  TAB: REPORTS
    # ════════════════════════════════════════════
    def _tab_reports(self):
        cf = self.content_frame
        self._page_header(cf, "📊 Reports & Analytics", "Monthly summary and expense breakdown")

        s = self._get_summary()
        conn = get_conn()
        uid = self.user_id

        # ── Monthly Summary ──────────────────────────────────────────────
        month_f = card(cf)
        month_f.pack(fill="x", padx=28, pady=(0,14))
        inner = styled_frame(month_f, bg=COLORS["card"])
        inner.pack(fill="x", padx=20, pady=16)
        tk.Label(inner, text="📅 This Month's Summary", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).pack(anchor="w", pady=(0,12))

        month_str = date.today().strftime("%Y-%m")

        m_income = conn.execute(
            "SELECT COALESCE(SUM(amount),0) FROM income WHERE user_id=? AND date LIKE ?",
            (uid, f"{month_str}%")
        ).fetchone()[0]
        m_exp = conn.execute(
            "SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND date LIKE ?",
            (uid, f"{month_str}%")
        ).fetchone()[0]
        m_emi = conn.execute(
            "SELECT COALESCE(SUM(emi_amount),0) FROM emi_loans WHERE user_id=?", (uid,)
        ).fetchone()[0]
        m_save = m_income - (m_exp + m_emi)

        row_f = styled_frame(inner, bg=COLORS["card"])
        row_f.pack(fill="x")
        for title, val, color in [
            ("Monthly Income",   f"₹{m_income:,.2f}", COLORS["accent2"]),
            ("Monthly Expenses", f"₹{m_exp:,.2f}",    COLORS["danger"]),
            ("Monthly EMI",      f"₹{m_emi:,.2f}",    COLORS["warning"]),
            ("Monthly Savings",  f"₹{m_save:,.2f}",   COLORS["success"] if m_save >= 0 else COLORS["danger"]),
        ]:
            c = tk.Frame(row_f, bg=COLORS["surface"],
                         highlightthickness=1, highlightbackground=COLORS["border"])
            c.pack(side="left", expand=True, fill="x", padx=6)
            tk.Label(c, text=title, font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["surface"]).pack(anchor="w", padx=12, pady=(10,2))
            tk.Label(c, text=val, font=("Segoe UI", 13, "bold"),
                     fg=color, bg=COLORS["surface"]).pack(anchor="w", padx=12, pady=(0,10))

        # ── Expense by Category ──────────────────────────────────────────
        cat_f = card(cf)
        cat_f.pack(fill="x", padx=28, pady=(0,14))
        ci = styled_frame(cat_f, bg=COLORS["card"])
        ci.pack(fill="x", padx=20, pady=16)
        tk.Label(ci, text="📂 Expense by Category (All Time)", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).pack(anchor="w", pady=(0,12))

        cat_data = conn.execute(
            "SELECT category, SUM(amount) FROM expenses WHERE user_id=? GROUP BY category ORDER BY SUM(amount) DESC",
            (uid,)
        ).fetchall()

        if cat_data:
            total_exp = sum(r[1] for r in cat_data)
            cat_colors = [COLORS["accent"], COLORS["accent2"], COLORS["danger"],
                          COLORS["warning"], "#AA66CC", "#5BC0EB"]
            for i, (cat, amt) in enumerate(cat_data):
                pct = (amt / total_exp * 100) if total_exp else 0
                bar_f = styled_frame(ci, bg=COLORS["card"])
                bar_f.pack(fill="x", pady=4)

                tk.Label(bar_f, text=cat, font=FONT_BODY,
                         fg=COLORS["text"], bg=COLORS["card"], width=14, anchor="w").pack(side="left")

                bar_bg = tk.Frame(bar_f, bg=COLORS["surface"], height=18, width=300)
                bar_bg.pack(side="left", padx=8)
                bar_bg.pack_propagate(False)
                bar_fill = tk.Frame(bar_bg, bg=cat_colors[i % len(cat_colors)],
                                    height=18, width=int(pct * 3))
                bar_fill.pack(side="left")

                tk.Label(bar_f, text=f"₹{amt:,.0f}  ({pct:.1f}%)",
                         font=FONT_SMALL, fg=COLORS["text_dim"], bg=COLORS["card"]).pack(side="left")
        else:
            tk.Label(ci, text="No expense data yet", font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["card"]).pack(pady=10)

        # ── Savings Formula ──────────────────────────────────────────────
        sf = card(cf)
        sf.pack(fill="x", padx=28, pady=(0,20))
        si = styled_frame(sf, bg=COLORS["card"])
        si.pack(fill="x", padx=20, pady=16)
        tk.Label(si, text="💎 Savings Formula", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["card"]).pack(anchor="w")
        formula = (f"Savings  =  Total Income  −  ( Total Expenses  +  Total EMI )\n"
                   f"         =  ₹{s['income']:,.2f}  −  ( ₹{s['expenses']:,.2f}  +  ₹{s['emi']:,.2f} )\n"
                   f"         =  ₹{s['savings']:,.2f}")
        tk.Label(si, text=formula, font=FONT_MONO,
                 fg=COLORS["accent2"], bg=COLORS["card"],
                 justify="left", pady=8).pack(anchor="w", padx=8)

        conn.close()

    # ── UTILITY ──────────────────────────────────────────────────────────
    def _page_header(self, cf, title, subtitle):
        hdr = styled_frame(cf, bg=COLORS["bg"])
        hdr.pack(fill="x", padx=28, pady=(24,12))
        tk.Label(hdr, text=title, font=FONT_TITLE,
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(anchor="w")
        tk.Label(hdr, text=subtitle, font=FONT_SMALL,
                 fg=COLORS["text_dim"], bg=COLORS["bg"]).pack(anchor="w")
        separator(cf, bg=COLORS["border"]).pack(fill="x", padx=28, pady=(0,12))


# ─────────────────────────────────────────────
#  EDIT DIALOGS
# ─────────────────────────────────────────────

class EditIncomeDialog:
    def __init__(self, parent, income_id, reload_cb):
        self.income_id = income_id
        self.reload_cb = reload_cb
        conn = get_conn()
        row = conn.execute(
            "SELECT source, amount, income_type, date FROM income WHERE income_id=?",
            (income_id,)
        ).fetchone()
        conn.close()

        self.win = tk.Toplevel(parent)
        self.win.title("Edit Income")
        self.win.geometry("400x340")
        self.win.configure(bg=COLORS["bg"])
        self.win.grab_set()

        wrap = styled_frame(self.win, bg=COLORS["bg"])
        wrap.pack(expand=True, fill="both", padx=30, pady=24)
        tk.Label(wrap, text="✏ Edit Income", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(anchor="w", pady=(0,12))

        fields = [("Source", row[0]), ("Amount", row[1]), ("Type", row[2]), ("Date", row[3])]
        self.entries = {}
        for lbl, val in fields:
            tk.Label(wrap, text=lbl, font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["bg"]).pack(anchor="w")
            if lbl == "Type":
                e = ttk.Combobox(wrap, values=INCOME_TYPES, state="readonly", font=FONT_BODY)
                e.set(val)
            else:
                e = tk.Entry(wrap, font=FONT_BODY, bg=COLORS["input_bg"],
                             fg=COLORS["text"], insertbackground=COLORS["accent"],
                             relief="flat", highlightthickness=1,
                             highlightbackground=COLORS["border"])
                e.insert(0, str(val))
            e.pack(fill="x", pady=(2,10), ipady=6)
            self.entries[lbl] = e

        btn(wrap, "Save Changes", self._save, color=COLORS["accent2"], fg=COLORS["bg"]).pack(fill="x", pady=(8,0))

    def _save(self):
        try:
            src  = self.entries["Source"].get().strip()
            amt  = float(self.entries["Amount"].get())
            typ  = self.entries["Type"].get()
            dt   = self.entries["Date"].get().strip()
            conn = get_conn()
            conn.execute(
                "UPDATE income SET source=?, amount=?, income_type=?, date=? WHERE income_id=?",
                (src, amt, typ, dt, self.income_id)
            )
            conn.commit()
            conn.close()
            self.reload_cb()
            self.win.destroy()
            messagebox.showinfo("Success", "Income updated! ✅")
        except ValueError:
            messagebox.showerror("Error", "Invalid input")


class EditExpenseDialog:
    def __init__(self, parent, expense_id, reload_cb):
        self.expense_id = expense_id
        self.reload_cb  = reload_cb
        conn = get_conn()
        row = conn.execute(
            "SELECT category, amount, date, description FROM expenses WHERE expense_id=?",
            (expense_id,)
        ).fetchone()
        conn.close()

        self.win = tk.Toplevel(parent)
        self.win.title("Edit Expense")
        self.win.geometry("400x380")
        self.win.configure(bg=COLORS["bg"])
        self.win.grab_set()

        wrap = styled_frame(self.win, bg=COLORS["bg"])
        wrap.pack(expand=True, fill="both", padx=30, pady=24)
        tk.Label(wrap, text="✏ Edit Expense", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(anchor="w", pady=(0,12))

        self.entries = {}
        for lbl, val in [("Category", row[0]), ("Amount", row[1]), ("Date", row[2]), ("Description", row[3])]:
            tk.Label(wrap, text=lbl, font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["bg"]).pack(anchor="w")
            if lbl == "Category":
                e = ttk.Combobox(wrap, values=EXPENSE_CATEGORIES, state="readonly", font=FONT_BODY)
                e.set(val)
            else:
                e = tk.Entry(wrap, font=FONT_BODY, bg=COLORS["input_bg"],
                             fg=COLORS["text"], insertbackground=COLORS["accent"],
                             relief="flat", highlightthickness=1,
                             highlightbackground=COLORS["border"])
                e.insert(0, str(val or ""))
            e.pack(fill="x", pady=(2,10), ipady=6)
            self.entries[lbl] = e

        btn(wrap, "Save Changes", self._save, color=COLORS["accent2"], fg=COLORS["bg"]).pack(fill="x", pady=(8,0))

    def _save(self):
        try:
            cat  = self.entries["Category"].get()
            amt  = float(self.entries["Amount"].get())
            dt   = self.entries["Date"].get().strip()
            desc = self.entries["Description"].get().strip()
            conn = get_conn()
            conn.execute(
                "UPDATE expenses SET category=?, amount=?, date=?, description=? WHERE expense_id=?",
                (cat, amt, dt, desc, self.expense_id)
            )
            conn.commit()
            conn.close()
            self.reload_cb()
            self.win.destroy()
            messagebox.showinfo("Success", "Expense updated! ✅")
        except ValueError:
            messagebox.showerror("Error", "Invalid input")


class EditEmiDialog:
    def __init__(self, parent, loan_id, reload_cb):
        self.loan_id   = loan_id
        self.reload_cb = reload_cb
        conn = get_conn()
        row = conn.execute(
            "SELECT loan_name, total_amount, emi_amount, interest_rate, remaining_months, start_date FROM emi_loans WHERE loan_id=?",
            (loan_id,)
        ).fetchone()
        conn.close()

        self.win = tk.Toplevel(parent)
        self.win.title("Edit EMI")
        self.win.geometry("400x440")
        self.win.configure(bg=COLORS["bg"])
        self.win.grab_set()

        wrap = styled_frame(self.win, bg=COLORS["bg"])
        wrap.pack(expand=True, fill="both", padx=30, pady=24)
        tk.Label(wrap, text="✏ Edit EMI / Loan", font=FONT_H2,
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(anchor="w", pady=(0,12))

        self.entries = {}
        fields = [
            ("Loan Name",      row[0]),
            ("Total Amount",   row[1]),
            ("EMI Amount",     row[2]),
            ("Interest Rate",  row[3]),
            ("Remaining Months", row[4]),
            ("Start Date",     row[5]),
        ]
        for lbl, val in fields:
            tk.Label(wrap, text=lbl, font=FONT_SMALL,
                     fg=COLORS["text_dim"], bg=COLORS["bg"]).pack(anchor="w")
            e = tk.Entry(wrap, font=FONT_BODY, bg=COLORS["input_bg"],
                         fg=COLORS["text"], insertbackground=COLORS["accent"],
                         relief="flat", highlightthickness=1,
                         highlightbackground=COLORS["border"])
            e.insert(0, str(val))
            e.pack(fill="x", pady=(2,8), ipady=6)
            self.entries[lbl] = e

        btn(wrap, "Save Changes", self._save, color=COLORS["accent2"], fg=COLORS["bg"]).pack(fill="x", pady=(8,0))

    def _save(self):
        try:
            e = self.entries
            name   = e["Loan Name"].get().strip()
            total  = float(e["Total Amount"].get())
            emi    = float(e["EMI Amount"].get())
            rate   = float(e["Interest Rate"].get())
            months = int(e["Remaining Months"].get())
            start  = e["Start Date"].get().strip()
            conn   = get_conn()
            conn.execute(
                """UPDATE emi_loans SET loan_name=?, total_amount=?, emi_amount=?,
                   interest_rate=?, remaining_months=?, start_date=? WHERE loan_id=?""",
                (name, total, emi, rate, months, start, self.loan_id)
            )
            conn.commit()
            conn.close()
            self.reload_cb()
            self.win.destroy()
            messagebox.showinfo("Success", "EMI updated! ✅")
        except (ValueError, TypeError):
            messagebox.showerror("Error", "Invalid input")


# ─────────────────────────────────────────────
#  LAUNCHERS
# ─────────────────────────────────────────────

def _launch_auth():
    root = tk.Tk()
    AuthWindow(root)
    root.mainloop()

def _launch_dashboard(user_id, full_name):
    root = tk.Tk()
    FinanceApp(root, user_id, full_name)
    root.mainloop()

# ─────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    _launch_auth()
