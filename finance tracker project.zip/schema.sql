-- ══════════════════════════════════════════════════════════════════
--  PERSONAL FINANCE TRACKER — SQL SCHEMA
--  DBMS Project | SQLite Database
--  Tables: users, income, expenses, emi_loans
-- ══════════════════════════════════════════════════════════════════

-- PRAGMA to enable Foreign Key constraints in SQLite
PRAGMA foreign_keys = ON;


-- ─────────────────────────────────────────────────────────
--  TABLE 1: users
--  Stores registered user accounts
--  Primary Key: user_id (AUTO INCREMENT)
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    user_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    username   TEXT    NOT NULL UNIQUE,
    password   TEXT    NOT NULL,           -- SHA-256 hashed password
    full_name  TEXT    NOT NULL,
    email      TEXT    NOT NULL UNIQUE,
    created_at TEXT    DEFAULT (DATE('now'))
);


-- ─────────────────────────────────────────────────────────
--  TABLE 2: income
--  Stores all income entries per user
--  Foreign Key: user_id → users(user_id)
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS income (
    income_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL,
    source      TEXT    NOT NULL,                   -- e.g. "Tech Corp Salary"
    amount      REAL    NOT NULL CHECK(amount > 0),
    income_type TEXT    NOT NULL DEFAULT 'salary',  -- salary/freelance/business/etc
    date        TEXT    NOT NULL,                   -- YYYY-MM-DD
    description TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);


-- ─────────────────────────────────────────────────────────
--  TABLE 3: expenses
--  Stores all expense entries per user
--  Foreign Key: user_id → users(user_id)
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
    expense_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL,
    category    TEXT    NOT NULL,                   -- Food/Rent/Travel/Shopping/Entertainment/Other
    amount      REAL    NOT NULL CHECK(amount > 0),
    date        TEXT    NOT NULL,                   -- YYYY-MM-DD
    description TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);


-- ─────────────────────────────────────────────────────────
--  TABLE 4: emi_loans
--  Stores loan and EMI details per user
--  Foreign Key: user_id → users(user_id)
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS emi_loans (
    loan_id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id           INTEGER NOT NULL,
    loan_name         TEXT    NOT NULL,                        -- e.g. "Home Loan"
    total_amount      REAL    NOT NULL CHECK(total_amount > 0),
    emi_amount        REAL    NOT NULL CHECK(emi_amount > 0),
    interest_rate     REAL    NOT NULL DEFAULT 0,              -- Annual %
    remaining_months  INTEGER NOT NULL CHECK(remaining_months >= 0),
    start_date        TEXT    NOT NULL,                        -- YYYY-MM-DD
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);


-- ══════════════════════════════════════════════════════════════════
--  DATABASE RELATIONSHIPS
-- ══════════════════════════════════════════════════════════════════
--
--   users (user_id) ──┬──► income   (user_id)
--                     ├──► expenses (user_id)
--                     └──► emi_loans(user_id)
--
--  • One-to-Many: One user can have MANY income records
--  • One-to-Many: One user can have MANY expense records
--  • One-to-Many: One user can have MANY EMI/loan records
--  • ON DELETE CASCADE: Deleting a user removes all their data
--
-- ══════════════════════════════════════════════════════════════════


-- ─────────────────────────────────────────────────────────
--  SAMPLE DATA (Optional — for testing)
-- ─────────────────────────────────────────────────────────

-- Insert a sample user (password = "test123" hashed with SHA-256)
INSERT INTO users (username, password, full_name, email)
VALUES (
    'student1',
    'a7c4e...',   -- Use Python: hashlib.sha256(b"test123").hexdigest()
    'Rahul Sharma',
    'rahul@example.com'
);

-- Sample income
INSERT INTO income (user_id, source, amount, income_type, date)
VALUES (1, 'Company Salary', 50000, 'salary', '2025-03-01');

INSERT INTO income (user_id, source, amount, income_type, date)
VALUES (1, 'Freelance Project', 15000, 'freelance', '2025-03-10');

-- Sample expenses
INSERT INTO expenses (user_id, category, amount, date, description)
VALUES (1, 'Food',   3500, '2025-03-05', 'Monthly groceries');

INSERT INTO expenses (user_id, category, amount, date, description)
VALUES (1, 'Rent',   12000, '2025-03-01', 'House rent');

INSERT INTO expenses (user_id, category, amount, date, description)
VALUES (1, 'Travel', 2000, '2025-03-12', 'Train tickets');

-- Sample EMI
INSERT INTO emi_loans (user_id, loan_name, total_amount, emi_amount, interest_rate, remaining_months, start_date)
VALUES (1, 'Laptop Loan', 45000, 1500, 8.5, 30, '2024-09-01');


-- ─────────────────────────────────────────────────────────
--  USEFUL QUERIES
-- ─────────────────────────────────────────────────────────

-- Total income for user_id = 1
SELECT SUM(amount) AS total_income FROM income WHERE user_id = 1;

-- Total expenses by category
SELECT category, SUM(amount) AS total
FROM expenses WHERE user_id = 1
GROUP BY category ORDER BY total DESC;

-- Savings calculation
SELECT
    (SELECT COALESCE(SUM(amount), 0) FROM income WHERE user_id = 1) -
    (SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE user_id = 1) -
    (SELECT COALESCE(SUM(emi_amount), 0) FROM emi_loans WHERE user_id = 1)
AS net_savings;

-- Monthly report
SELECT
    strftime('%Y-%m', date) AS month,
    SUM(amount) AS monthly_expense
FROM expenses WHERE user_id = 1
GROUP BY month ORDER BY month DESC;
