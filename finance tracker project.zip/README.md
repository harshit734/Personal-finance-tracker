# Personal Finance Tracker
## DBMS Mini Project | Python + SQLite

---

## PROJECT OVERVIEW

A desktop application to manage personal finances — income, expenses, EMI/loans,
and savings — built with Python (Tkinter UI) and SQLite (database).

---

## TECH STACK

| Layer      | Technology         |
|------------|--------------------|
| Language   | Python 3.x         |
| UI Library | Tkinter + ttk      |
| Database   | SQLite (via sqlite3)|
| Security   | SHA-256 (hashlib)  |

---

## HOW TO RUN

### Requirements
- Python 3.8 or higher (Tkinter is included by default)
- No external pip packages needed!

### Steps
```
1. Download finance_tracker.py

2. Open terminal / command prompt

3. Run:
   python finance_tracker.py

4. The app opens. Register a new account → Login → Start tracking!

5. A file called finance_tracker.db is auto-created in the same folder.
   This is your SQLite database.
```

---

## DATABASE DESIGN

### Tables

#### 1. users
| Column     | Type    | Constraint      |
|------------|---------|-----------------|
| user_id    | INTEGER | PRIMARY KEY     |
| username   | TEXT    | UNIQUE NOT NULL |
| password   | TEXT    | NOT NULL (hashed)|
| full_name  | TEXT    | NOT NULL        |
| email      | TEXT    | UNIQUE NOT NULL |
| created_at | TEXT    | DEFAULT today   |

#### 2. income
| Column      | Type    | Constraint                        |
|-------------|---------|-----------------------------------|
| income_id   | INTEGER | PRIMARY KEY                       |
| user_id     | INTEGER | FOREIGN KEY → users(user_id)      |
| source      | TEXT    | NOT NULL                          |
| amount      | REAL    | CHECK(amount > 0)                 |
| income_type | TEXT    | salary/freelance/business/etc     |
| date        | TEXT    | YYYY-MM-DD                        |
| description | TEXT    | optional                          |

#### 3. expenses
| Column     | Type    | Constraint                    |
|------------|---------|-------------------------------|
| expense_id | INTEGER | PRIMARY KEY                   |
| user_id    | INTEGER | FOREIGN KEY → users(user_id)  |
| category   | TEXT    | Food/Rent/Travel/etc          |
| amount     | REAL    | CHECK(amount > 0)             |
| date       | TEXT    | YYYY-MM-DD                    |
| description| TEXT    | optional                      |

#### 4. emi_loans
| Column          | Type    | Constraint                    |
|-----------------|---------|-------------------------------|
| loan_id         | INTEGER | PRIMARY KEY                   |
| user_id         | INTEGER | FOREIGN KEY → users(user_id)  |
| loan_name       | TEXT    | NOT NULL                      |
| total_amount    | REAL    | CHECK(total_amount > 0)       |
| emi_amount      | REAL    | CHECK(emi_amount > 0)         |
| interest_rate   | REAL    | Annual %                      |
| remaining_months| INTEGER | CHECK(>= 0)                   |
| start_date      | TEXT    | YYYY-MM-DD                    |

### Relationships
```
users (1) ──────────────── (∞) income
users (1) ──────────────── (∞) expenses
users (1) ──────────────── (∞) emi_loans

Type: One-to-Many
Constraint: ON DELETE CASCADE (if user deleted, all data deleted)
```

---

## FEATURES IMPLEMENTED

✅ User Registration & Login (with hashed passwords)
✅ Dashboard with KPI cards (Income, Expenses, EMI, Salary, Savings)
✅ Remaining Balance displayed prominently
✅ Income Management (Add, Edit, Delete)
✅ Expense Tracker with 6 categories (Add, Edit, Delete)
✅ EMI / Loan Tracker (Add, Edit, Delete)
✅ Monthly Report
✅ Expense breakdown by category (with visual bar chart)
✅ Savings Formula display

---

## SAVINGS FORMULA

```
Savings = Total Income − (Total Expenses + Total EMI)
```

---

## CRUD OPERATIONS USED

| Operation | SQL Command | Where Used            |
|-----------|-------------|------------------------|
| Create    | INSERT INTO | Add income/expense/EMI |
| Read      | SELECT      | Dashboard, tables      |
| Update    | UPDATE SET  | Edit dialogs           |
| Delete    | DELETE FROM | Delete buttons         |

---

## PROJECT FILES

```
finance_tracker/
├── finance_tracker.py    ← Main Python application (run this)
├── schema.sql            ← SQL CREATE TABLE statements
├── README.md             ← This file
└── finance_tracker.db    ← Auto-created SQLite database on first run
```
